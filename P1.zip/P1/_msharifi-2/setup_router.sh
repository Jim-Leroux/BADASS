#!/bin/sh

# 1. Active le transfert de paquets IP (Forwarding)
sysctl -w net.ipv4.ip_forward=1

# 2. Lance Zebra (gestionnaire de l'interface et des routes)
/usr/lib/frr/zebra -d -A 127.0.0.1 -s 90000

# 3. Lance OSPFD (routage interne)
/usr/lib/frr/ospfd -d -A 127.0.0.1

# 4. Lance ISISD (moteur IS-IS)
/usr/lib/frr/isisd -d -A 127.0.0.1

# 5. Lance BGPD (routage externe BGP)
/usr/lib/frr/bgpd -d -A 127.0.0.1

echo "Tous les services FRR ont été lancés en arrière-plan."
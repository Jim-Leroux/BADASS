PARTIE 1 : Configuration de l'infrastructure GNS3 avec Docker

Cette phase consiste à préparer les briques de base (Underlay) pour permettre la future mise en place d'un réseau virtuel (Overlay).

1. Choix des Images Docker

Nous utilisons des images légères basées sur Alpine Linux pour optimiser les ressources de la machine hôte.

Hôtes (End-points) : Utilisation de busybox. Cette suite logicielle fournit les outils essentiels comme ping ou traceroute pour valider que les paquets traversent correctement les routeurs.

Routeurs : Utilisation de FRRouting (FRR). C'est la suite de routage standard qui transforme un conteneur Linux en un routeur capable de gérer plusieurs protocoles simultanément grâce à des programmes spécialisés appelés Daemons.

2. Architecture de FRRouting (Daemons)

Zebra : C'est le chef d'orchestre. Il reçoit les routes calculées par OSPF, IS-IS ou BGP, les centralise dans une table de routage unique et les inscrit dans le noyau Linux pour que le trafic puisse circuler physiquement.

OSPF / IS-IS (L'Underlay) :

Ils servent à découvrir les autres "entremetteurs" (routeurs) du réseau.

Ils envoient des "appels" sur des adresses Multicast (adresses où les autres routeurs écoutent en permanence).

OSPF utilise l'IP Multicast (L3), tandis qu'IS-IS utilise la MAC Multicast (L2). Cela permet à IS-IS de fonctionner même si les routeurs n'ont pas encore d'adresses IP configurées.

Leur rôle principal est d'annoncer les Loopbacks (/32). La Loopback est l'identité stable d'un routeur (son "numéro de sécurité sociale") : elle ne tombe jamais.

Cela permet d'obtenir la "toile" complète de l'infrastructure.

BGP (L'Overlay) :

Il s'appuie sur la connectivité établie par l'Underlay (les Loopbacks).

Son rôle est de servir d'annuaire des hôtes (les extrémités).

Au fur et à mesure que les hôtes se manifestent (via ARP ou DHCP), BGP apprend leurs adresses et prévient immédiatement les autres routeurs pour qu'ils sachent où envoyer les données.

ARP fait le lien entre l'adresse IP (Logique) et la MAC (Physique). Un hôte demande : « Qui a cette IP ? » pour obtenir la MAC correspondante.

DHCP distribue automatiquement des adresses IP aux hôtes dès qu'ils se branchent.

Dans ton lab, BGP EVPN « espionne » ces échanges pour découvrir tes hôtes sans que tu aies à les déclarer manuellement.

3. Topologie Réseau (Les 5 Réseaux)

Le déploiement crée une segmentation en couches pour isoler le transport du service :

LAN 1 : Segment entre l'hôte 1 et le routeur 1.

LAN 2 : Segment entre l'hôte 2 et le routeur 2.

Transit (Underlay) : Le réseau physique reliant R1 et R2 via le switch (10.0.0.0/24).

Loopback R1 : L'adresse d'identité stable de R1 (1.1.1.1/32).

Loopback R2 : L'adresse d'identité stable de R2 (2.2.2.2/32).